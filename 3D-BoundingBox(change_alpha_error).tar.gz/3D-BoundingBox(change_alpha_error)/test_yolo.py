"""
Images must be in ./Kitti/testing/image_2/ and camera matricies in ./Kitti/testing/calib/

Uses YOLO to obtain 2D box, PyTorch to get 3D box, plots both

SPACE bar for next image, any other key to exit
"""

from mxnet.gluon.data.vision import transforms
from torch_lib.Dataset import *
from library.Math import *
from library.Plotting import *
from torch_lib import ClassAverages
from model import *
from mxnet import gluon
from gluoncv import model_zoo, data, utils
from matplotlib import pyplot as plt
from mxnet import nd, image
import mxnet
import time
import cv2
import numpy as np
from mxnet.gluon import nn
import os
import time

import numpy as np
import cv2


import argparse

transform_fn = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([.485, .456, .406], [.229, .224, .225])
])

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


parser = argparse.ArgumentParser()

parser.add_argument("--image-dir", default="eval/image_2/",
                    help="Relative path to the directory containing images to detect. Default \
                    is eval/image_2/")

# TODO: support multiple cal matrix input types
parser.add_argument("--cal-dir", default="camera_cal/",
                    help="Relative path to the directory containing camera calibration form KITTI. \
                    Default is camera_cal/")

parser.add_argument("--video", action="store_true",
                    help="Weather or not to advance frame-by-frame as fast as possible. \
                    By default, this will pull images from ./eval/video")

parser.add_argument("--show-yolo", action="store_true",
                    help="Show the 2D BoundingBox detecions on a separate image")

parser.add_argument("--hide-debug", action="store_true",
                    help="Supress the printing of each 3d location")


def plot_regressed_3d_bbox(img, cam_to_img, box_2d, dimensions, alpha, theta_ray, img_2d=None):

    # the math! returns X, the corners used for constraint
    location, X = calc_location(dimensions, cam_to_img, box_2d, alpha, theta_ray)

    orient = alpha + theta_ray

    if img_2d is not None:
        plot_2d_box(img_2d, box_2d)

    plot_3d_box(img, cam_to_img, orient, dimensions, location) # 3d boxes

    return location

def main():

    FLAGS = parser.parse_args()
    # load 3d model
    model = TDbox()
    path = '/home/dilu/3D-BoundingBox/epoch_90'
    model.load_parameters(path, ctx=ctx)


    # load yolo model
    # net.initialize(ctx=ctx)
    path = '/home/dilu/gluon-cv/docs/tutorials/detection/yolo3_darknet53_voc_0000_0.7009.params'
    net = model_zoo.get_model('yolo3_darknet53_voc', pretrained=False, ctx=ctx)
    net.load_parameters(path, ctx=ctx)
    averages = ClassAverages.ClassAverages()

    # TODO: clean up how this is done. flag?
    angle_bins = generate_bins(2)

    image_dir = FLAGS.image_dir
    cal_dir = FLAGS.cal_dir
    if FLAGS.video:
        if FLAGS.image_dir == "eval/image_2/" and FLAGS.cal_dir == "camera_cal/":
            image_dir = "eval/video/2011_09_26/image_2/"
            cal_dir = "eval/video/2011_09_26/"


    img_path = os.path.abspath(os.path.dirname(__file__)) + "/" + image_dir
    # using P_rect from global calibration file
    calib_path = os.path.abspath(os.path.dirname(__file__)) + "/" + cal_dir
    calib_file = calib_path + "calib_cam_to_cam.txt"

    # using P from each frame
    # calib_path = os.path.abspath(os.path.dirname(__file__)) + '/Kitti/testing/calib/'

    try:
        ids = [x.split('.')[0] for x in sorted(os.listdir(img_path))]
    except:
        print("\nError: no images in %s"%img_path)
        exit()

    for id in ids:

        start_time = time.time()

        img_file = img_path + id + ".png"

        # P for each frame
        # calib_file = calib_path + id + ".txt"
        # img_file = '/home/dilu/gluon-cv/2.jpg'
        truth_img = cv2.imread(img_file)
        # truth_img =cv2.resize(truth_img,(1200,600))
        h1,w1,_ = truth_img.shape
        img = np.copy(truth_img)
        # yolo_img = np.copy(truth_img)
        # test_img = nd.random.normal(shape=(1,3,512,512),ctx=ctx)
        # test_img = nd.random.normal(shape=(1,3,416,416),ctx=ctx)
        # test_img = nd.array(truth_img,cpu(0))
        # recolor, reformat
        # test_img = transform_fn(test_img)
        # test_img = nd.array(nd.expand_dims(test_img,axis=0),ctx=ctx)

        truth_img = nd.array(truth_img)
        imgs = [truth_img]
        x, imgs = data.transforms.presets.yolo.transform_test(imgs, short=512, max_size=1024, stride=1, mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
        #x, img = data.transforms.presets.yolo.load_test(im_fname, short=512)
        #print('Shape of pre-processed image:', x.shape)
        x = nd.array(x,ctx=mxnet.gpu())
        # print imgs
        h2,w2,_ = imgs.shape
        rate = (float(h1)/float(h2) + float(w1)/float(w2))/2
        print rate
        class_IDs, scores, bounding_boxs = net(x)
        class_IDs, scores, bounding_boxs = nd.squeeze(class_IDs).asnumpy(),nd.squeeze(scores).asnumpy(),nd.squeeze(bounding_boxs).asnumpy()
        length,_ = bounding_boxs.shape
        # print class_IDs.shape, scores.shape, bounding_boxs.shape
        for i in range(length):
            # print class_ID, score, bounding_box 
            class_ID = 'DontCare'
            if class_IDs[i]==14: class_ID = 'Pedestrian' 
            if class_IDs[i]==6: class_ID = 'Car' 
            if scores[i] < 0.5:
                continue
            print class_IDs[i]
            bounding_box = bounding_boxs[i,:]*rate

            # ~~~~~~
            # gt = np.array([[712.40 ,143.00],[810.73, 307.92]])
            # print gt/np.reshape(bounding_box,[2,2])

            bounding_box = np.reshape(bounding_box,[2,2]).astype(np.int)
            # print bounding_box
            # gt 712.40 143.00 810.73 307.92
            # bounding_box = np.array([[712,143],[810,307]])
            # print bounding_box
            if not averages.recognized_class(class_ID):  
                print 'label is not inside' 
                continue

            # this is throwing when the 2d bbox is invalid
            # TODO: better check

            try:
                object = DetectedObject(img, class_ID, bounding_box, calib_file)
            except:
                continue
            theta_ray = object.theta_ray
            input_img = object.img
            proj_matrix = object.proj_matrix
            box_2d = bounding_box
            detected_class = class_ID

            input_tensor = nd.expand_dims(nd.array(input_img, ctx=ctx),axis=0)
            [orient, conf, dim] = model(input_tensor)

            orient, conf, dim = nd.squeeze(orient).asnumpy(), nd.squeeze(conf).asnumpy(),nd.squeeze(dim).asnumpy()

            dim += averages.get_item(detected_class)

            argmax = np.argmax(conf)
            orient = orient[argmax, :]
            cos = orient[0]
            sin = orient[1]
            tan = sin/cos
            # alpha = np.arctan2(sin, cos)
            alpha = np.arctan(tan)
            alpha += angle_bins[argmax]
            alpha -= np.pi

            if FLAGS.show_yolo:
                location = plot_regressed_3d_bbox(img, proj_matrix, box_2d, dim, alpha, theta_ray, truth_img)
            else:
                location = plot_regressed_3d_bbox(img, proj_matrix, box_2d, dim, alpha, theta_ray)

            if not FLAGS.hide_debug:
                print('Estimated pose: %s'%location)

        if FLAGS.show_yolo:
            numpy_vertical = np.concatenate((truth_img, img), axis=0)
            cv2.imshow('SPACE for next image, any other key to exit', numpy_vertical)
        else:
            cv2.imshow('3D detections', img)

        if not FLAGS.hide_debug:
            print("\n")
            print('Got %s poses in %.3f seconds'%(length, time.time() - start_time))
            print('-------------')

        if FLAGS.video:
            cv2.waitKey(1)
        else:
            if cv2.waitKey(0) != 32: # space bar
                exit()

if __name__ == '__main__':
    main()
