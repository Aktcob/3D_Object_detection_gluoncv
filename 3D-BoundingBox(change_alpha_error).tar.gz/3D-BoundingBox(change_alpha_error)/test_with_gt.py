"""
This script will use the 2D box from the label rather than from YOLO
"""
from torch_lib.Dataset import *
from library.Math import *
from library.Plotting import *
from torch_lib import ClassAverages
import time
import os
import cv2
import mxnet as mx
from model import *
# import torch
# import torch.nn as nn
# from torch.autograd import Variable
# from torchvision.models import vgg
import numpy as np

# to run car by car
single_car = False
ctx = mx.gpu(0)

def plot_regressed_3d_bbox(img, truth_img, cam_to_img, box_2d, dimensions, alpha, theta_ray):

    # the math! returns X, the corners used for constraint
    location, X = calc_location(dimensions, cam_to_img, box_2d, alpha, theta_ray)

    orient = alpha + theta_ray

    plot_2d_box(truth_img, box_2d)
    plot_3d_box(img, cam_to_img, orient, dimensions, location) # 3d boxes

    return location

def main():

    model = TDbox()
    path = '/home/dilu/3D-BoundingBox/epoch_90'
    model.load_parameters(path, ctx=ctx)

    # dataset = Dataset(os.path.abspath(os.path.dirname(__file__)) + '/Kitti/training')
    dataset = Dataset(os.path.abspath(os.path.dirname(__file__)) + '/eval')
    # print dataset
    averages = ClassAverages.ClassAverages()

    all_images = dataset.all_objects()

    for key in sorted(all_images.keys()):
        start = time.time()
        data = all_images[key]

        truth_img = data['Image']
        img = np.copy(truth_img)
        objects = data['Objects']
        cam_to_img = data['Calib']

        for object in objects:
            label = object.label
            theta_ray = object.theta_ray
            input_img = object.img

            # input_tensor = torch.zeros([1,3,224,224])
            # input_tensor[0,:,:,:] = input_img
            # input_tensor.cuda()
            input_tensor = nd.expand_dims(nd.array(input_img, ctx=ctx),axis=0)
            [orient, conf, dim] = model(input_tensor)
            # orient = orient.cpu().data.numpy()[0, :, :]
            # conf = conf.cpu().data.numpy()[0, :]
            # dim = dim.cpu().data.numpy()[0, :]
            orient, conf, dim = nd.squeeze(orient).asnumpy(), nd.squeeze(conf).asnumpy(),nd.squeeze(dim).asnumpy()

            dim += averages.get_item(label['Class'])
            argmax = np.argmax(conf)
            orient = orient[argmax, :]
            cos = orient[0]
            sin = orient[1]
            tan = sin/cos
            # alpha = np.arctan2(sin, cos)
            alpha = np.arctan(tan)
            print 'dalpha',alpha
            alpha += dataset.angle_bins[argmax]
            print '0-2pi alpha', alpha
            alpha -= np.pi
            
            print 'alpha',alpha
            location = plot_regressed_3d_bbox(img, truth_img, cam_to_img, label['Box_2D'], dim, alpha, theta_ray)

            print('Estimated pose: %s'%location)
            print('Truth pose: %s'%label['Location'])
            print('-------------')

            # plot car by car
            if single_car:
                numpy_vertical = np.concatenate((truth_img, img), axis=0)
                cv2.imshow('2D detection on top, 3D prediction on bottom', numpy_vertical)
                cv2.waitKey(0)

        # plot image by image
        if not single_car:
            numpy_vertical = np.concatenate((truth_img, img), axis=0)
            cv2.imshow('2D detection on top, 3D prediction on bottom', numpy_vertical)
            cv2.waitKey(0)
        
        over = time.time()
        print 'processing time is: ', over-start, 'ms' 

if __name__ == '__main__':
    main()
